<?php 
session_start();
error_reporting(0);
include('config.php');
if(isset($_POST['save']))
{
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];
  $age=$_POST['age'];
  $sql="insert into tbluser(firstname,lastname,age)values(:firstname,:lastname,:age)";
  $query=$dbh->prepare($sql);
  $query->bindParam(':firstname',$firstname,PDO::PARAM_STR);
  $query->bindParam(':lastname',$lastname,PDO::PARAM_STR);
  $query->bindParam(':age',$age,PDO::PARAM_STR);
  $query->execute();
  $LastInsertId=$dbh->lastInsertId();
  if ($LastInsertId>0) 
  {
    echo '<script>alert("Registered successfully")</script>';
    echo "<script>window.location.href ='index.php'</script>";
  }
  else
  {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }
}
?>

<form class="forms-sample" method="post" enctype="multipart/form-data" class="form-horizontal">
  <div class="row ">
    <div class="form-group col-md-12">
      <label >First Name </label>
      <input type="text" name="firstname" class="form-control" value="" id="firstname" placeholder="Enter First Name" required>
    </div>
  </div>
   <div class="row ">
    <div class="form-group col-md-12">
      <label >Last Name </label>
      <input type="text" name="lastname" class="form-control" value="" id="lastname" placeholder="Enter Last Name" required>
    </div>
  </div>
  <div class="row ">
    <div class="form-group col-md-12">
      <label >Age</label>
      <input type="text" name="age" value="" placeholder="Enter Age" class="form-control" id="age"required>
    </div>

  </div>
  <button type="submit" style="float: left;" name="save" class="btn btn-primary  mr-2 mb-4">Save</button>
</form>